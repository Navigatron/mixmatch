package client;

/*

    PlaceGUI.java - THE MEAT AND POTATOES.

    Goal 1 - Interact with the place server
        Status: Working on it
    Goal 2 - Interact with the user graphically
        Status: Working on it
    Goal 3 - Make stressed students even more stressed.
        Status: Achieved.

*/
import java.util.*;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.canvas.*;
import javafx.scene.input.*;
import javafx.geometry.*;
import javafx.event.*;

import java.text.SimpleDateFormat;

import subscriber.Subscriber;
import place.*;
import place.network.*;

public class PlaceGUI extends Application implements Subscriber {


    private int port;
    private String host;
    private String username;

    private Backend backend;

    // Graphics Things that can Change
    private GraphicsContext gc; // For drawing to the canvas
    private Label label; // For printing information

    private PlaceColor nextColor = PlaceColor.BLACK;

    /*
    Application calls this to initialize internal vars.
    */
    public void init(){
        String[] args = getParameters().getRaw().toArray(new String[0]);
        host = args[0];
        port = Integer.parseInt(args[1]);
        username = args[2];
        //Create backend
        backend = new Backend(host, port, username);
        //Wait for backend initialization
        try{
            synchronized(backend){
                if(backend.getBoard()==null){
                    backend.wait();
                }
            }
        }catch(InterruptedException e){
            System.out.println("Thread Interupted Exception while waiting for backend initialization. Terminating.");
            System.exit(1);
        }
        //Start backend
        new Thread(backend).start();
        //Subscribe to the backend to recieve updates when we are ready.
    }
    /*
    Application calls this when it's ready to run.
    Initialize the network and model and all that stuff.
    Call a different function to make the GUI.
    @param mainStage The stage to put all the GUI stuff onto.
    */
    public void start( Stage mainStage ) {
        makeMeAGUI(mainStage);
        for(PlaceTile[] array : backend.getBoard().getBoard()){
            for(PlaceTile tile : array){
                drawTile(tile);
            }
        }
        backend.subscribe(this);
    }
    /*
    Initialize the GUI bits specifically.
    @param stage the stage to throw all this onto.
    */
    private void makeMeAGUI(Stage stage){
        /*
        stage
        border pane
        left:
            vbox
            color buttons
        center:
            canvas?
        bottom:
            Status Text
        */
        //Bottom
        label = new Label();
        label.setText("Connected To Server.");
        //Center
        Canvas canvas = new Canvas(750,750);
        gc = canvas.getGraphicsContext2D();
        canvas.setOnMouseClicked(event -> {
            canvasClick(event.getX(), event.getY());
        });
        canvas.setOnMouseMoved(event -> {
            canvasMove(event);
        });
        //Left
        Button[] buttons = generateButtons();
        VBox vbox = new VBox();
        for(Button boo : buttons){
            vbox.getChildren().add(boo);
        }
        //BorderPane
        BorderPane bpane = new BorderPane();
        bpane.setLeft(vbox);
        bpane.setBottom(label);
        bpane.setCenter(canvas);
        //Scene
        Scene scene = new Scene(bpane);
        //Stage
        stage.setTitle("Place: "+username);
        stage.setScene(scene);
        stage.sizeToScene();
        stage.show();
    }

    private void canvasMove(MouseEvent event){
        double x = event.getX();
        double y = event.getY();
        int dim = backend.getBoard().DIM;
        double gdim = gc.getCanvas().getWidth(); // canvas is square
        // pixels per tile
        double ppt = gdim/dim;
        int tilex = (int)(x/ppt);
        int tiley = (int)(y/ppt);
        PlaceTile tile = backend.getBoard().getBoard()[tiley][tilex];
        String out = "Tile: ";
        // Printing in X,Y because that's convention.
        out += "("+tile.getCol()+","+tile.getRow()+"), ";
        out += "Color: "+tile.getColor()+", ";
        out += "User: "+(tile.getOwner().equals("")?"None":tile.getOwner())+", ";
        String time="None";
        if(tile.getTime()!=0){
            SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            time = sdfDate.format(tile.getTime());
        }
        out += "Time: "+time;
        label.setText(out);
    }

    private void canvasClick(double x, double y){
        int dim = backend.getBoard().DIM;
        double gdim = gc.getCanvas().getWidth(); // canvas is square
        // pixels per tile
        double ppt = gdim/dim;
        int tilex = (int)(x/ppt);
        int tiley = (int)(y/ppt);
        backend.send(
            new PlaceRequest<PlaceTile>(
                PlaceRequest.RequestType.CHANGE_TILE,
                new PlaceTile(
                    tiley,
                    tilex,
                    username,
                    nextColor,
                    System.currentTimeMillis()
                )
            )
        );
        System.out.println("Tile Change Sent.");
    }

    private Button[] generateButtons(){
        Button[] buttons = new Button[16];
        for(PlaceColor color : PlaceColor.values()){
            int[] colors = new int[]{
                color.getRed(),
                color.getGreen(),
                color.getBlue()
            };
            String[] ss = new String[]{
                Integer.toHexString(colors[0]),
                Integer.toHexString(colors[1]),
                Integer.toHexString(colors[2])
            };
            for(int i=0; i<3; i++){
                if(ss[i].length()==1){
                    ss[i]="0"+ss[i];
                }
            }
            String background=ss[0]+ss[1]+ss[2];
            //Calculate Luminosity
            double[] cs = new double[]{
                (double)color.getRed(),
                (double)color.getGreen(),
                (double)color.getBlue()
            };
            for(double c : cs){
                c=c/255;
                if(c<=0.03928){
                    c=c/12.92;
                }else{
                    c=Math.pow(((c+0.055)/1.055), 2.4);
                }
            }
            double lumens = 0.2126*cs[0]+0.7152*cs[1]+0.0722*cs[2];
            //If luminosity is low, use a light foreground.
            String foreground = "000000";/**/
            if(lumens<=0.179){
                foreground = "ffffff";
            }//*/
            int num = color.getNumber();
            Button b = new Button(""+num);
            b.setStyle(
                "-fx-border-color: #"+background+";"+
                "-fx-border-width: 10px;"+
                "-fx-background-color: #"+background+";"+
                "-fx-font-size: 1em;"+
                "-fx-text-fill: #"+foreground+""
            );
            b.setOnAction((event) -> {
                buttonClick(event, num);
            });
            buttons[num]=b;
        }
        return buttons;
    }

    private void buttonClick(ActionEvent event, int num){
        System.out.println("Button number "+num+" has been clicked.");
        nextColor = PlaceColor.values()[num];
    }

    private void drawTile(PlaceTile tile){
        int dim = backend.getBoard().DIM;
        int row = tile.getRow();
        int col = tile.getCol();
        double gdim = gc.getCanvas().getWidth(); // canvas is square
        // Calc size of one unit
        double unit = gdim/(double)dim;
        // Calc tile top left corner
        double x = (double)col*unit;
        double y = (double)row*unit;
        PlaceColor pc = tile.getColor();
        Color color = Color.rgb(pc.getRed(), pc.getGreen(), pc.getBlue());
        gc.setFill(color);//Color
        //xywh
        gc.fillRect(x,y,unit,unit);
    }

    /*
    Exposes refresh to the outside world.
    Tell the application to call refresh at the next oppertunity.
    @param t The observable object calling this
    @param o honestly I don't know.
    */
    @Override
    public void update(PlaceTile tile){
        javafx.application.Platform.runLater(()->{refresh(tile);});
    }

    private void refresh(PlaceTile tile){
        drawTile(tile);
    }

    public static void main( String[] args ) {
        // Step One - Validate Input
        // Quickest out - not matching 3 args
        if(args.length!=3){
            System.out.println("Usage: java PlaceGUI host port username");
            System.exit(1);
        }
        // Host will fail on connection if invalid
        // Validate PORT
        int port = Integer.parseInt(args[1]);
        if(port<0 || port>65535){
            System.out.println("Error: Invalid Port.");
            System.out.println("Port must be between 0 and 65535.");
            System.exit(1);
        }
        // username is a string, all good.
        launch( args );
    }
}
