package client;

/*

    Backend.java - THE SECRET BACK ROOM.

    PTUI and GUI are for data IO with the user. They don't store it
    or talk to the server - That's my job.

    @author Ethan Witherington

*/

import java.net.Socket;
import java.net.UnknownHostException;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;

import place.*;
import place.network.*;

import java.util.HashSet;
import subscriber.*;

public class Backend implements Runnable, Subscribable{

    private Socket portal;

    private ObjectInputStream inbound;
    private ObjectOutputStream outbound;

    private volatile boolean isKill = false;

    private PlaceBoard bord;

    private HashSet<Subscriber> fans = new HashSet<Subscriber>();

    /*
    Create backend
    @args host Host to connect to
    @args port port to connect to
    @args username username to use
    */
    public Backend(String host, int port, String username){
        try{
            portal = new Socket(host, port);
            System.out.println("Connected!");
        }catch(UnknownHostException e){
            DieWithError("ERROR: Unkown Host.", e);
            return;
        }catch(IOException e){
            DieWithError("ERROR: Error opening socket to server.", e);
            return;
        }
        try{
            outbound = new ObjectOutputStream(portal.getOutputStream());
            outbound.flush(); // Send initialized serialization stream header so server does not block.
        }catch(IOException e){
            DieWithError("ERROR: Error getting outbound data stream.", e);
            return;
        }
        try{
            inbound = new ObjectInputStream(portal.getInputStream());
        }catch(IOException e){
            DieWithError("ERROR: Error getting inbound data stream.", e);
            return;
        }

        // Login Handshake

        //Send a login Request
        System.out.print("Logging in...");
        write(new PlaceRequest<String>(PlaceRequest.RequestType.LOGIN, username));
        //Read the login reply
        PlaceRequest<?> reply = read();
        if(reply.getType()==PlaceRequest.RequestType.LOGIN_SUCCESS){
            System.out.println(" Login Successful!");
        }else if(reply.getType()==PlaceRequest.RequestType.ERROR){
            System.out.println(" Username in use! Try again.");
            System.exit(0);
        }else{
            System.out.println(" Failure - Invalid response from server.");
            System.exit(1);
        }
        // We've gotten to this point, username is valid. Request the Board next.
        PlaceRequest<?> maybeBoard = read();
        if(maybeBoard.getType()==PlaceRequest.RequestType.BOARD){
            this.bord = (PlaceBoard)maybeBoard.getData();
            System.out.println("\nConnection Sequence Complete!\n");
            synchronized(this){
                this.notifyAll();
            }
        }else{
            System.out.println("ERROR: Server failed to complete login sequence.");
            System.exit(1);
        }
    }
    /*
    Run the backend
    */
    @Override
    public void run(){
        while(!isKill){
            PlaceRequest<?> req = read();
            /*
                Request Types:
                LOGIN	           String
                LOGIN_SUCCESSFUL   String
                ERROR	           String
                BOARD	           Board
                CHANGE_TILE	       Tile
                TILE_CHANGED	   Tile
            */
            if (req.getType() == PlaceRequest.RequestType.TILE_CHANGED) {
                PlaceTile tile = (PlaceTile)req.getData();
                bord.setTile(tile);
                for(Subscriber fan : fans){
                    fan.update(tile);
                }
            }
        }
    }
    /*
    getBoard
    @returns the board
    */
    public PlaceBoard getBoard(){
        return bord;
    }
    /*
    allow a fan to recieve updates
    @args fan to subscribe
    */
    @Override
    public void subscribe(Subscriber fan){
        if(!fans.contains(fan)){
            fans.add(fan);
        }else{
            System.out.println("ERROR: Duplicate subscription calls from a UI. Something is very wrong.");
        }
    }
    /*
    unsubscibe an unhappy customer
    @args fan the unhappy customer
    */
    @Override
    public void unsubscribe(Subscriber fan){
        if(fans.contains(fan)){
            fans.remove(fan);
        }else{
            System.out.println("ERROR: Unsibscribe request from non-subscribed UI.");
        }
    }
    /*
    Read a request from the server
    @returns the data read
    */
    private PlaceRequest<?> read(){
        PlaceRequest<?> req=null;
        try{
            req = (PlaceRequest<?>) inbound.readUnshared();
        }catch(ClassNotFoundException e){
            DieWithError("ERROR: Client sent Non-Place request.", e);
        }catch(IOException e){
            DieWithError("ERROR: Error reading from server data stream.", e);
        }
        return req;
    }
    /*
    Send data to the server
    @args data to send
    */
    private void write(PlaceRequest<?> thing){
        try{
            outbound.writeUnshared(thing);
        }catch(IOException e){
            System.out.println("ERROR: Error writing to client datastream.");
        }
    }
    /*
    expose write to the outer world
    @args the data to send
    */
    public void send(PlaceRequest<?> req){
        write(req);
    }
    /*
    Something has gone wrong, print info and die.
    @args message the mesage to print
    @args e the exception that is the problem.
    */
    private void DieWithError(String message, Exception e){
        System.out.println(message);
        System.out.println(e.getMessage());
        // Client side, crashes are OKAY, system.exit auto closes streams.
        System.exit(1);
    }
}
