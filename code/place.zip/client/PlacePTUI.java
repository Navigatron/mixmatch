package client;

/*

    PlacePTUI.java - THE COMMAND VIEW

    @author Ethan Witherington

*/

import subscriber.Subscriber;
import place.*;
import place.network.*;


public class PlacePTUI implements Subscriber{
    private Backend backRoom;
    private boolean maySend = false;
    private long lastSend = 0;
    private String name = "";
    /*
    Constructor
    @param name username
    @param backend network connection
    */
    public PlacePTUI(String name, Backend backend){
        this.backRoom = backend;
        this.name = name;
        maySend = true;
        // Wait for backend setup
        try{
            synchronized(backRoom){
                if(backRoom.getBoard()==null){
                    backRoom.wait();
                }
            }
        }catch(InterruptedException e){
            System.out.println("Thread Interupted Exception while waiting for backend initialization. Terminating.");
            System.exit(1);
        }
        // Connection established, Subscribe.
        System.out.println(backRoom.getBoard());
    }
    /*
    run this thing
    */
    private void run(){
        while(true){
            // If it's good to go, read input. else, wait.
            if(System.currentTimeMillis()-lastSend>500){
                synchronized(this){
                    System.out.print("[row][col][color]: ");
                    maySend = true;
                }
                PlaceRequest<PlaceTile> req = processInput(new java.util.Scanner(System.in).nextLine());
                lastSend = System.currentTimeMillis();
                maySend = false;
                backRoom.send(req);
                System.out.println("Change Sent.");
            }else{
                try{
                    Thread.sleep(500);
                }catch(InterruptedException e){
                    System.out.println("PTUI Thread Sleep Interupted");
                    System.exit(1);
                }

            }
        }
    }
    /*
        Process input
        @param iy input
        @returns placeRequest
    */
    private PlaceRequest<PlaceTile> processInput(String iy){
        String[] args = iy.split(" ");
        if(args.length>=1 && args[0].equals("-1")){
            System.out.println("Goodbye");
            System.exit(0);
        }
        if(args.length!=3){
            System.out.println("Row, Col, Color. Try again.");
            return processInput(new java.util.Scanner(System.in).nextLine());
        }
        // row col user color time
        PlaceColor c = HexToColor(args[2]);
        if(c==null){
            System.out.println("Invalid Color. Remember, Colors are in Hex. Try Again.");
            System.out.print("[row][col][color]: ");
            return processInput(new java.util.Scanner(System.in).nextLine());
        }

        PlaceTile tile = new PlaceTile(
            Integer.parseInt(args[0]),
            Integer.parseInt(args[1]),
            name,
            c,
            System.currentTimeMillis()
        );
        if(backRoom.getBoard().isValid(tile)){
            return new PlaceRequest<PlaceTile>(
                PlaceRequest.RequestType.CHANGE_TILE,
                tile
            );
        }else{
            System.out.println("Invalid Row/Column. Try Again.");
            System.out.print("[row][col][color]: ");
            return processInput(new java.util.Scanner(System.in).nextLine());
        }
    }
    /*
    Turn a string into a hex color via PlaceColor
    @param c hex color value 0->F
    @return PlaceColor
    */
    private PlaceColor HexToColor(String c){
        for(PlaceColor co : PlaceColor.values()){
            if(co.toString().equals(c)){
                return co;
            }
        }
        return null;
    }
    /*
    PTUI update thing
    @args tile to place
    @return nothing
    */
    @Override
    public synchronized void update(PlaceTile tile){
        System.out.println("Tile Change Recieved.");
        // Print the Board
        System.out.println(backRoom.getBoard());
        // If go for read input
        if(maySend){
            System.out.print("[row][col][color]: ");
        }else{
            System.out.println("Waiting...");
        }
    }

    public static void main(String[] args){
        // Step One - Validate Input
        // Quickest out - not matching 3 args
        if(args.length!=3){
            System.out.println("Usage: java PlacePTUI host port username");
            System.exit(1);
        }
        // Host will fail on connection if invalid
        // Validate PORT
        int port = Integer.parseInt(args[1]);
        if(port<0 || port>65535){
            System.out.println("Error: Invalid Port.");
            System.out.println("Port must be between 0 and 65535.");
            System.exit(1);
        }
        // username is a string, all good.
        // Create the backend
        Backend theBack = new Backend(args[0], port, args[2]);
        PlacePTUI ptui = new PlacePTUI(args[2], theBack);
        theBack.subscribe(ptui);
        new Thread(theBack).start();
        ptui.run();
    }
}
