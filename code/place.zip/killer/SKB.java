package killer;
import java.net.*;
import java.io.*;
import place.*;
import place.network.*;
public class SKB implements Runnable{
    private String host;
    private int port;
    private Socket socket;
    private ObjectOutputStream outbound;
    private ObjectInputStream inbound;
    public boolean connected = false;
    @Override
    public void run(){
        while(connected){
            PlaceRequest<?> req = read();
            if(req==null){
                System.out.println("Server has Disconnected.");
                connected = false;
            }
            System.out.println();
            System.out.println("PACKET RECIEVED: "+req);
        }
    }
    public void reconnect(){
        connect();
        InitOutbound();
        InitInbound();
    }
    public void close(){
        try{
            socket.close();
        }catch(IOException e){
            System.out.println("IOException closing our socket.");
            System.out.println(e.getMessage());
        }

    }
    private PlaceRequest<?> read(){
        PlaceRequest<?> req=null;
        try{
            req = (PlaceRequest<?>) inbound.readUnshared();
        }catch(ClassNotFoundException e){
            System.out.println("Class not found exception reading from server.");
            System.exit(1);
        }catch(IOException e){
            System.out.println("IOException reading from server. Possibly kicked? use \'reconnect\' to reconnect.");
        }
        return req;
    }
    public void write(PlaceRequest<?> thing){
        try{
            outbound.writeUnshared(thing);
        }catch(IOException e){
            System.out.println("ERROR: Error writing to datastream.");
        }
    }
    public void write2(Object thing){
        try{
            outbound.writeUnshared(thing);
        }catch(IOException e){
            System.out.println("ERROR: Error writing class to datastream.");
        }
    }
    public void InitInbound(){
        System.out.println("Itializing Object Input Stream.");
        try{
            inbound = new ObjectInputStream(socket.getInputStream());
        }catch(IOException e){
            System.out.println("IOException opening input stream.");
            System.out.println("Error message: "+e.getMessage());
        }
        System.out.println("Object Input Stream Initialized.");
    }
    public void InitOutbound(){
        System.out.println("Itializing Object Output Stream.");
        try{
            outbound = new ObjectOutputStream(socket.getOutputStream());
        }catch(IOException e){
            System.out.println("IOException opening output stream.");
            System.out.println("Error message: "+e.getMessage());
        }
        System.out.println("Object Output Stream Initialized.");
        System.out.print("Flushing Stream.");
        try{
            outbound.flush();
        }catch(IOException e){
            System.out.println("IOException when creating socket.");
            System.out.println("Error message: "+e.getMessage());
        }
        System.out.println("Done.");
    }
    public SKB(String host, int port){
        this.host = host;
        this.port = port;
    }
    public void connect(){
        System.out.println("Connecting to Target...");
        try{
            socket = new Socket(host, port);
        }catch(UnknownHostException e){
            System.out.println("Unknown Host. Dying.");
            System.exit(0);
        }catch(IOException e){
            System.out.println("IOException when creating socket.");
            System.out.println("Error message: "+e.getMessage());
        }
        connected = true;
        System.out.println("Connection established.");
    }
}
