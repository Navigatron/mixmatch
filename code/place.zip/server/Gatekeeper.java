package server;

/*

    Gatekeeper.java - THE ALL POWERFULL GATEKEEPER.

    Determine the fate of lost souls
    - Legit Clients
        - Speak to a CUSTOMER SERVICE REPRESENTATIVE.
    - Everyone Else
        - CAST INTO THE ABYSS.

*/

import java.net.ServerSocket;
import java.net.Socket;
import java.io.IOException;

public class Gatekeeper implements Runnable{
    private ServerSocket socket;
    private Accountant jim;
    public Gatekeeper(int port, int DIM){
        try{
            socket = new ServerSocket(port);
        }catch(IOException e){
            System.out.println("ERROR: Error creating server socket.");
            System.out.println(e.getMessage());
            System.exit(1);
        }
        jim = new Accountant(DIM);
    }
    @Override
    public void run(){
        while(true){
            try {
                Socket newcomer;
                newcomer = socket.accept();
                CSR csr = new CSR(newcomer, jim);
                new Thread(csr).start();
            }catch(IOException e){
                System.out.println("ERROR: Error accepting client connection.");
                System.out.println(e.getMessage());
            }
        }
    }
}
