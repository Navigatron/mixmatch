package server;

public class PlaceServer{
    public static void main(String[] args){
        // Step One - Validate Input
        // Quickest out - not matching 2 args
        if(args.length!=2){
            System.out.println("Usage: java PlaceServer port DIM");
            System.exit(1);
        }
        // Validate PORT
        int port = Integer.parseInt(args[0]);
        if(port<0 || port>65535){
            System.out.println("Error: Invalid Port.");
            System.out.println("Port must be between 0 and 65535.");
            System.out.println("Note: Root/Admin may be required to use a port below 1024.");
            System.exit(1);
        }
        // Validate DIM
        int DIM = Integer.parseInt(args[1]);
        if(DIM<=0){
            System.out.println("Error: Invalid DIM.");
            System.out.println("DIM must be greater than or equal to 1.");
            System.exit(1);
        }
        // Easter Egg
        if(DIM>=10000){
            System.out.println("Large DIM detected.");
            System.out.println("Good luck.");
        }

        // Create Gatekeeper
        new Thread(new Gatekeeper(port, DIM)).start();
    }
}
