package server;

/*

    CSR.java - CUSTOMER SERVICE REPRESENTATIVE

    Created by the ALL-POWERFULL GATEKEEPER to deal with Pesky Clients.

*/

import java.net.Socket;
import java.io.IOException;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OptionalDataException;

import place.*;
import place.network.*;

import subscriber.Subscriber;


public class CSR implements Runnable, Subscriber{

    private Socket client;
    private ObjectInputStream inbound;
    private ObjectOutputStream outbound;

    private volatile boolean isKill = false;

    private Accountant jim;

    private boolean login = false;
    private String name;

    private int lastPlace = 0;

    public CSR(Socket customer, Accountant jim){
        this.jim = jim;
        client = customer;
        try{
            outbound = new ObjectOutputStream(client.getOutputStream());
            outbound.flush(); // So client does not block;
        }catch(IOException e){
            DieWithError("ERROR: Error getting client output stream.", e);
            return;
        }
        try{
            inbound = new ObjectInputStream(client.getInputStream());
        }catch(IOException e){
            DieWithError("ERROR: Error getting client input stream.", e);
            return;
        }
    }
    @Override
    public void run(){
        while(!isKill){
            // Get Input
            PlaceRequest<?> req = read();
            if(isKill){return;}
            // process input
            /*
                Request Types:
                LOGIN	           String
                LOGIN_SUCCESSFUL   String
                ERROR	           String
                BOARD	           Board
                CHANGE_TILE	       Tile
                TILE_CHANGED	   Tile
            */
            if (req.getType() == PlaceRequest.RequestType.LOGIN) {
                String name = (String) req.getData();
                System.out.println("Login request with username "+name);
                if(jim.registerUsername(name)){
                    write(new PlaceRequest<String>(PlaceRequest.RequestType.LOGIN_SUCCESS, ""));
                    write(new PlaceRequest<PlaceBoard>(PlaceRequest.RequestType.BOARD, jim.getBoard()));
                    jim.subscribe(this);
                    login = true;
                    this.name = name;
                }else{
                    write(new PlaceRequest<String>(PlaceRequest.RequestType.ERROR, "Username Taken"));
                    DieWithStyle();
                }
                continue;
            }
            if(login && req.getType() == PlaceRequest.RequestType.CHANGE_TILE){
                if(System.currentTimeMillis()-lastPlace>=500){
                    // Accept change
                    PlaceTile tile = (PlaceTile)req.getData();
                    if(jim.requestChange(tile)){
                        // Change successful
                        System.out.println("Successful Change. User: \'"+name+"\', Tile: "+tile);
                    }else{
                        // Change was invalid
                        System.out.println("Invalid Change, Disconnecting. User: \'"+name+"\', Tile: "+tile);
                        write(new PlaceRequest<String>(PlaceRequest.RequestType.ERROR, "Invalid Tile Change Request."));
                        DieWithStyle();
                    }
                }else{
                    // Discard and kick
                    System.out.println("Player \'"+name+"\' sent too many requests. Disconnecting.");
                    DieWithStyle();
                }
            }

        }
    }

    @Override
    public void update(PlaceTile tile){
        System.out.println("Shipping tile change to client \'"+name+"\'");
        write(new PlaceRequest<PlaceTile>(PlaceRequest.RequestType.TILE_CHANGED, tile));
    }

    private PlaceRequest<?> read(){
        PlaceRequest<?> req=null;
        try{
            req = (PlaceRequest<?>) inbound.readUnshared();
        }catch(ClassNotFoundException e){
            DieWithError("ERROR: Client sent Non-Place request.", e);
        }catch(IOException e){
            if(req==null){
                if(name!=null){
                    System.out.println("Client \'"+name+"\' has Disconnected.");
                }else{
                    System.out.println("Client has Disconnected without registering username.");
                }
                DieWithStyle();
                return null;
            }else{
                System.out.println("ERROR: Error reading from client input stream. Dropping Connection.");
            }
            DieWithStyle();
        }

        return req;
    }

    private void write(PlaceRequest<?> thing){
        try{
            outbound.writeUnshared(thing);
        }catch(IOException e){
            System.out.println("ERROR: Error writing to client datastream.");
        }
    }

    // Unregister username and close resources.
    private void DieWithStyle(){
        // Unregister username
        if(login){
            jim.unsubscribe(this);
            if(name!=null){
                jim.unregisterUsername(name);
            }
        }
        // Terminate this CSR.
        disconnect();
    }

    // Print error messages, then gracefully close.
    private void DieWithError(String message, Exception e){
        System.out.println(message);
        System.out.println(e.getMessage());
        DieWithStyle();
    }

    // Close streams and terminate.
    private void disconnect(){
        try{
            inbound.close();
            outbound.close();
        }catch(Exception e){
            // There's not much we can do about this.
            System.out.println("ERROR: Error closing streams. Critical.");
            System.out.println(e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
        isKill = true;
    }
}
