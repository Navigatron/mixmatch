package server;

/*

    Accounting.java - THE ACCOUNTANT

    Keep records of who is where, what is where
    Maintain an orderly line.
    read/write one at a time.

*/

import place.*;
import java.util.HashSet;
import subscriber.*;

public class Accountant implements Subscribable{
    private PlaceBoard bord;
    private HashSet<String> names = new HashSet<String>();
    // This accountant has a fanbase that subscribe to his mailing list.
    private HashSet<Subscriber> fans = new HashSet<Subscriber>();
    public Accountant(int DIM){
        bord = new PlaceBoard(DIM);
        System.out.println("Board Initialized with side length "+DIM);
    }
    public boolean registerUsername(String name){
        if(names.contains(name)){
            System.out.println("Attempted double-login; username \'"+name+"\'");
            return false;
        }else{
            System.out.println("Username registered: \'"+name+"\'");
            names.add(name);
            return true;
        }
    }
    public void unregisterUsername(String name){
        if(names.contains(name)){
            System.out.println("Username \'"+name+"\' unregistered.");
            names.remove(name);
        }
    }
    public synchronized PlaceBoard getBoard(){
        return this.bord;
    }
    public synchronized boolean requestChange(PlaceTile tile){
        if(bord.isValid(tile)){
            bord.setTile(tile);
            // Broadcast Change
            for(Subscriber fan : fans){
                fan.update(tile);
            }
            return true;
        }else{
            return false;
        }
    }
    @Override
    public void subscribe(Subscriber fan){
        if(!fans.contains(fan)){
            fans.add(fan);
        }else{
            System.out.println("ERROR: Duplicate subscription calls from a CSR. Something is very wrong.");
        }
    }
    @Override
    public void unsubscribe(Subscriber fan){
        if(fans.contains(fan)){
            fans.remove(fan);
        }else{
            System.out.println("ERROR: Unsibscribe request from non-subscribed CSR.");
        }
    }
}
