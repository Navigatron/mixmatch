package subscriber;
import place.PlaceTile;
public interface Subscriber{
    public void update(PlaceTile tile);
}
