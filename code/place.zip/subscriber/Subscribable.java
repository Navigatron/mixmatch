package subscriber;

public interface Subscribable{
    public void subscribe(Subscriber fan);
    public void unsubscribe(Subscriber fan);
}
