import java.net.Socket;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
public class Ear implements Runnable{
    Socket s;
    BufferedReader br;
    public Ear(Socket s){
        this.s = s;
        try{
            br = new BufferedReader(new InputStreamReader(s.getInputStream()));
        }catch(IOException e){
            System.out.println("Couldn't get input stream");
            System.exit(0);
        }
    }
    public void run(){
        while(true){
            try{
                String in = br.readLine();
                if(in!=null){
                    System.out.println(in);
                }else{
                    System.out.println("Server closed Connection");
                    System.exit(0);
                }
            }catch(IOException e){
                System.out.println("Couldn't read line from socket");
                System.exit(0);
            }
        }
    }
}
