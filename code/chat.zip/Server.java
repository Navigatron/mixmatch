import java.net.ServerSocket;
import java.io.IOException;
import java.util.ArrayList;
public class Server implements Runnable{

    ServerSocket mySocket;

    ArrayList<CSR> callCenter = new ArrayList<CSR>();

    public Server(){
        try{
            mySocket = new ServerSocket(8080);
        }catch(IOException e){
            Die("Error opening server socket", e);
        }
    }

    public void run(){
        while(true){
            CSR newguy = null;
            try{
                newguy = new CSR(mySocket.accept(), this);
            }catch(IOException e){
                Die("Error accepting client connection", e);
            }
            callCenter.add(newguy);
            System.out.println("New Connection!");
            new Thread(newguy).start();
        }
    }

    private void Die(String problem, Exception e){
        System.out.println(problem);
        System.out.println(e.getMessage());
        e.printStackTrace();
        System.exit(1);
    }

    public void broadcast(String message){
        for(CSR carl : callCenter){
            carl.send(message);
        }
    }

    public static void main(String[] args) {
        Server myServer = new Server();
        myServer.run();
    }
}
