import java.net.Socket;
import java.io.BufferedReader;
import java.io.PrintWriter;
import java.io.InputStreamReader;
import java.io.IOException;
public class CSR implements Runnable{

    Socket client;
    Server s;
    boolean isRunning = true;
    BufferedReader br = null;
    PrintWriter pr = null;

    public CSR(Socket client, Server s){
        this.client = client;
        this.s = s;
        try{
            br = new BufferedReader(new InputStreamReader(client.getInputStream()));
        }catch(IOException e){
            Die("Could not get InputStream from connection", e);
        }
        try{
            pr = new PrintWriter(client.getOutputStream());
        }catch(IOException e){
            Die("Could not get OutputStream from connection", e);
        }
    }

    public void run(){
        while(isRunning){
            try{
                String input = br.readLine();
                if(input!=null){
                    System.out.println(input);
                    s.broadcast(input);
                }else{
                    isRunning = false;
                }
            }catch(IOException e){
                Die("Error reading from connection", e);
            }
        }
    }

    public void send(String message){
        pr.println(message);
        pr.flush();
    }

    private void Die(String problem, Exception e){
        System.out.println(problem);
        System.out.println(e.getMessage());
        e.printStackTrace();
        isRunning = false;
    }
}
