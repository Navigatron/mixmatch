import java.net.Socket;
import java.util.Scanner;
import java.io.PrintWriter;
import java.io.IOException;
import java.net.UnknownHostException;
public class Client implements Runnable{
    Socket conn = null;
    PrintWriter pr = null;
    Scanner scanner;
    public Client(String host, int port){
        try{
            conn = new Socket(host, port);
        }catch(UnknownHostException e){
            System.out.println("Couldn't find host");
            System.exit(0);
        }catch(IOException e){
            System.out.println("Really couldn't find host even though we tried extra hard this time");
            System.exit(0);
        }
        try{
            pr = new PrintWriter(conn.getOutputStream());
        }catch(IOException e){
            System.out.println("Couldn't get output stream");
            System.exit(0);
        }
        scanner = new Scanner(System.in);
        new Thread(new Ear(conn)).start();
    }
    public void run(){
        while(true){
            pr.println(scanner.nextLine());
            pr.flush();
        }
    }
    public static void main(String[] args) {
        Client me = new Client("", 8080);
        me.run();
    }
}
